﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KodtestJuniorConsole
{ 
    
    /*
    * Uppgift 1:
    * Förändra Main så att den anropar en metod i denna klass som har två numeriska inparametrar.
    * Metoden ska returnera summan av dessa inparametrar. 
    * Låt sedan Main skriva ut resultatet i konsollen.
    */

    class Exercise1
    {

        static public int Sum(int a, int b)
        {
            return a + b; 
        }
    }
}
