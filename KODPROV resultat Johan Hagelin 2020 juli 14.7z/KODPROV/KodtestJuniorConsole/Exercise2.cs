﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace KodtestJuniorConsole
{

    /*
    * Uppgift 2:
    * Låt Main istället anropa en metod i denna klass som läser input från konsollen.
    * Loopa sedan igenom det värdet som du fått in fyra gånger separerade med ett mellanrum.
    * Låt sedan metoden returnera den loopade textsträngen och skriv den till konsollen i Main.
    * Exempelvis: 4 4 4 4
    */

    class Exercise2
    {
        static public string FourAndSpaces()
        {

            string inputStr = Console.ReadLine();

            string resultingString = "";
            for(int i = 0; i < 4; i++)
            {
                resultingString += inputStr;
                if (i != 3)
                {
                    resultingString += " ";
                }
            }

            return resultingString;

        }
    }
}
