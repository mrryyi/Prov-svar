﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KodtestJuniorConsole
{

    /*
    * Uppgift 3:
    * Lägg till en metod i denna klass som läser två input-värden från konsollen och skicka in dessa i metoden från övning 1.
    * Låt sedan Main skriva ut resultatet.
    */

    class Exercise3
    {
        static public Int32 ReadTwoInputs()
        {
             
            Int32 a = Convert.ToInt32(Console.ReadLine());
            Int32 b = Convert.ToInt32(Console.ReadLine());

            return Exercise1.Sum(a, b);
        }
    }
}
