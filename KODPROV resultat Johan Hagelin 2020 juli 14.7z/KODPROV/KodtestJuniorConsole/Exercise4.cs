﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KodtestJuniorConsole
{

    /*
    * Uppgift 4:
    * Skapa en metod som läser av två input-värden från konsollen, validera att värdena är mellan 1 och 10.
    * Om något av värdena inte är mellan intervallet ska metoden slänga ett felmeddelande.
    * Låt sedan Main anropa metoden och vid fel så skriv ut ett felmeddelande i konsollen.
    */

    class Exercise4
    {
        static public void ValidateNums()
        {
            Int32 a = Convert.ToInt32(Console.ReadLine());
            Int32 b = Convert.ToInt32(Console.ReadLine());

            if ( !((a >= 1 && a <= 10 ) && (b >= 1 && b <= 10)) )
            {
                Console.WriteLine("Either or both not good");
            }
        }
    }
}
