﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KodtestJuniorConsole
{

    /*
    * Uppgift 5:
    * Snygga till din kod inför incheckning.
    */

    class Exercise5
    {
    }
}
